<?php
include_once("Request.php");

class Index {
    public $menu = array(
        'Meet/main' => array(
            'rules' => array(),
            'layer' => 2,
            'options' => array(
                array('id' => '3', 'title'=>'Ham', 'thumb' => 'http://localhost/test_api/ham.png'),
                array('id' => '4', 'title'=>'Tenderloin', 'thumb' => 'http://localhost/test_api/tenderloin.png'),
                array('id' => '5', 'title'=>'Kebab', 'thumb' => 'http://localhost/test_api/kebab.png')
            )
        ),
        'Bases' => array(
            'rules' => array('required' => true, 'max' => 1),
            'layer' => 1,
            'options' => array(
                array('id' => '1', 'title'=>'Normal', 'thumb' => 'http://localhost/test_api/normal.png'),
                array('id' => '2', 'title'=>'Cheese', 'thumb' => 'http://localhost/test_api/cheese.png')
            )
        ),
        'Salads/Secondary' => array(
            'rules' => array(),
            'layer' => 3,
            'options' => array(
                array('id' => '6', 'title'=>'Salad', 'thumb' => 'http://localhost/test_api/salad.png'),
                array('id' => '7', 'title'=>'Tomato', 'thumb' => 'http://localhost/test_api/tomato.png'),
                array('id' => '8', 'title'=>'Cucumber', 'thumb' => 'http://localhost/test_api/cucumber.png'),
                array('id' => '9', 'title'=>'Leek', 'thumb' => 'http://localhost/test_api/leek.png'),
                array('id' => '10', 'title'=>'Olives', 'thumb' => 'http://localhost/test_api/olives.png')
            )
        )
    );

    public function __construct(Request $data) {
        if($data->request->method == 'POST') {
            var_dump($data->request->params,123);
            if($data->request->params['action'] == 'create_order') {
                var_dump($data->request->params);
            }
        } else {
            if($data->request->params['action'] == 'get_menu') {

                echo json_encode($this->menu);
            }

            if($data->request->params['action'] == 'get_item') {
                $item = $this->get_item($data->request->params['item']);
                echo $item['thumb'];
            }
        }
    }

    public function get_item($id) {
        foreach ($this->menu as $group) {
            foreach($group['options'] as $item) {
                if($item['id'] == $id)
                    return $item;
            }
        }

        return false;
    }
}
$request = new Request($_REQUEST);
$index = new Index($request);
