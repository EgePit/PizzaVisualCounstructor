<?php

class Request {
    public $request;

    public function __construct(array $request) {
        $this->request = new stdClass();
        $this->request->params = $request;
        $this->request->method = $_SERVER['REQUEST_METHOD'];
    }
}